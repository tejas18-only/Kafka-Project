from airflow import DAG
from airflow.operators.python_operator import PythonOperator

from datetime import datetime
from models.fraud_detection_training import FraudDetectionTraining

def run_training():
    # trainer = FraudDetectionTraining(config_path="/path/to/src/producer/config.yaml")
    trainer = FraudDetectionTraining(config_path="/app/config.yaml")
    metrics = trainer.run_training_pipeline()
    print(metrics)

default_args = {
    "owner": "airflow",
    "start_date": datetime(2023, 1, 1),
}

with DAG(
    dag_id="fraud_detection_training_dag",
    default_args=default_args,
    schedule_interval="@daily",  # adjust as needed
    catchup=False,
) as dag:
    training_task = PythonOperator(
        task_id="train_fraud_model",
        python_callable=run_training,
    )
