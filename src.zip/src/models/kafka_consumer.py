# models/kafka_consumer.py
import os
import json
import logging
from typing import List, Dict, Optional
import pandas as pd
from confluent_kafka import Consumer, KafkaError, KafkaException

logger = logging.getLogger(__name__)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(module)s - %(message)s"
)

def _build_consumer(bootstrap_servers: str, group_id: str = "fraud_training_group") -> Consumer:
    """
    Build a PLAINTEXT confluent_kafka Consumer for local/self-managed Kafka.
    """
    conf = {
        "bootstrap.servers": bootstrap_servers,
        "group.id": group_id,
        "auto.offset.reset": "earliest",
        "enable.auto.commit": True,
    }
    return Consumer(conf)

def consume_batch(
    topic: str,
    bootstrap_servers: Optional[str] = None,
    max_messages: int = 2000,
    poll_timeout_sec: float = 1.0
) -> pd.DataFrame:
    """
    Consume up to `max_messages` messages from `topic` and return a DataFrame.
    If no messages are received, returns an empty DataFrame.
    """
    bootstrap_servers = bootstrap_servers or os.getenv("KAFKA_BOOTSTRAP_SERVER", "localhost:9092")
    logger.info("Consuming from topic=%s bootstrap=%s max_messages=%s", topic, bootstrap_servers, max_messages)

    consumer = _build_consumer(bootstrap_servers)
    consumer.subscribe([topic])

    rows: List[Dict] = []
    try:
        while len(rows) < max_messages:
            msg = consumer.poll(poll_timeout_sec)
            if msg is None:
                # no message this poll – continue polling until we hit the max or no data keeps coming
                continue
            if msg.error():
                if msg.error().code() == KafkaError._PARTITION_EOF:
                    logger.debug("Partition EOF")
                    continue
                raise KafkaException(msg.error())
            try:
                value = msg.value()
                if value is None:
                    continue
                record = json.loads(value.decode("utf-8")) if isinstance(value, (bytes, bytearray)) else json.loads(value)
                rows.append(record)
                if len(rows) % 200 == 0:
                    logger.info("Consumed %d messages...", len(rows))
            except Exception as e:
                logger.warning("Skipping bad record: %s", e)
                continue
    finally:
        consumer.close()

    df = pd.DataFrame(rows)
    logger.info("Batch consumed: %d messages", len(df))
    return df
