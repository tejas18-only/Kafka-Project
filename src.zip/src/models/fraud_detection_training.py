import os
import io
import yaml
import json
import boto3
import mlflow
import mlflow.xgboost
import logging
import numpy as np
import pandas as pd
import xgboost as xgb
from typing import Tuple
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_score, recall_score, f1_score
from dotenv import load_dotenv
from sqlalchemy import create_engine

from kafka_consumer import consume_batch

logger = logging.getLogger(__name__)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(module)s - %(message)s"
)

class FraudDetectionTraining:
    def __init__(self, config_path: str = "/app/config.yaml"):
        # Load env (.env is mounted at /app/.env in your compose)
        load_dotenv(dotenv_path=os.getenv("ENV_PATH", "/app/.env"))

        # Load config
        self.config = self._load_config(config_path)

        # Wire MLflow + MinIO env
        os.environ["MLFLOW_S3_ENDPOINT_URL"] = self.config["mlflow"]["s3_endpoint_url"]
        os.environ["AWS_ACCESS_KEY_ID"] = os.getenv("AWS_ACCESS_KEY_ID", "minio")
        os.environ["AWS_SECRET_ACCESS_KEY"] = os.getenv("AWS_SECRET_ACCESS_KEY", "minio123")

        mlflow.set_tracking_uri(self.config["mlflow"]["tracking_uri"])
        mlflow.set_experiment(self.config["mlflow"]["experiment_name"])

        # Data/I-O config
        self.topic = self.config["kafka"]["topic"]
        self.kafka_bootstrap_in_container = self.config["kafka"]["bootstrap_in_container"]
        self.local_fallback_csv = self.config["data"]["fallback_csv"]  # optional cache

        # PostgreSQL config
        pg_conf = self.config.get("postgresql", {})
        self.pg_connection_string = pg_conf.get("connection_string", None)
        if self.pg_connection_string:
            self.pg_engine = create_engine(self.pg_connection_string)
        else:
            self.pg_engine = None
            logger.warning("No PostgreSQL connection string found in config; skipped DB inserts.")

        # Make sure data directory exists (for fallback save)
        os.makedirs(os.path.dirname(self.local_fallback_csv), exist_ok=True)

    def _load_config(self, path: str) -> dict:
        with open(path, "r") as f:
            cfg = yaml.safe_load(f)
        logger.info("Loaded config from %s", path)
        return cfg

    def _fetch_data(self) -> pd.DataFrame:
        """
        Consume a batch from Kafka. If nothing arrives, try fallback CSV if exists.
        """
        df = consume_batch(
            topic=self.topic,
            bootstrap_servers=self.kafka_bootstrap_in_container,
            max_messages=self.config["data"]["max_batch"]
        )
        if df.empty:
            if os.path.exists(self.local_fallback_csv):
                logger.warning("Kafka returned no messages; loading fallback CSV: %s", self.local_fallback_csv)
                return pd.read_csv(self.local_fallback_csv)
            logger.warning("No data from Kafka and no fallback CSV found.")
        else:
            # Persist a rolling cache so you can train even if Kafka is quiet next run
            if os.path.exists(self.local_fallback_csv):
                df.to_csv(self.local_fallback_csv, mode="a", header=False, index=False)
            else:
                df.to_csv(self.local_fallback_csv, index=False)
        return df

    @staticmethod
    def _coerce_schema(df: pd.DataFrame) -> pd.DataFrame:
        """
        Ensure expected columns exist and types are sane.
        Expected minimally: transaction_id, amount, currency, merchant, timestamp, location, is_fraud
        """
        if "is_fraud" not in df.columns and "isFraud" in df.columns:
            df = df.rename(columns={"isFraud": "is_fraud"})

        # Drop rows without label
        df = df.dropna(subset=["is_fraud"])

        # Coerce label to int (0/1)
        df["is_fraud"] = df["is_fraud"].astype(int)

        # Ensure amount numeric
        if "amount" in df.columns:
            df["amount"] = pd.to_numeric(df["amount"], errors="coerce")

        # Timestamp to datetime (optional)
        if "timestamp" in df.columns:
            df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")

        # Keep only known useful columns if present
        keep = [c for c in ["transaction_id","amount", "currency", "merchant", "timestamp", "location", "is_fraud"] if c in df.columns]
        df = df[keep].dropna()

        # One-hot encode categoricals (except transaction_id and timestamp)
        cat_cols = [c for c in ["currency", "merchant", "location"] if c in df.columns]
        df = pd.get_dummies(df, columns=cat_cols, dummy_na=False)

        return df

    @staticmethod
    def _split(df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        X = df.drop(columns=["is_fraud", "transaction_id", "timestamp"], errors='ignore').values
        y = df["is_fraud"].values
        return train_test_split(X, y, test_size=0.2, random_state=42, stratify=y if len(np.unique(y)) == 2 else None)

    def _train(self, X_train, y_train) -> xgb.XGBClassifier:
        params = self.config["model"]
        model = xgb.XGBClassifier(
            n_estimators=params.get("n_estimators", 300),
            max_depth=params.get("max_depth", 6),
            learning_rate=params.get("learning_rate", 0.1),
            subsample=params.get("subsample", 0.8),
            colsample_bytree=params.get("colsample_bytree", 0.8),
            reg_alpha=params.get("reg_alpha", 0.0),
            reg_lambda=params.get("reg_lambda", 1.0),
            random_state=42,
            n_jobs=-1,
            eval_metric="logloss",
        )
        model.fit(X_train, y_train)
        return model

    @staticmethod
    def _eval(model: xgb.XGBClassifier, X_test, y_test) -> dict:
        y_pred = model.predict(X_test)
        return {
            "precision": float(precision_score(y_test, y_pred, zero_division=0)),
            "recall": float(recall_score(y_test, y_pred, zero_division=0)),
            "f1": float(f1_score(y_test, y_pred, zero_division=0)),
        }

    def _write_to_postgres(self, df: pd.DataFrame):
        if self.pg_engine is None:
            logger.warning("PostgreSQL engine not initialized, skipping DB write.")
            return
        try:
            # Insert or append to the transactions table
            df.to_sql('transactions', con=self.pg_engine, if_exists='append', index=False)
            logger.info("Wrote batch of %d records to PostgreSQL.", len(df))
        except Exception as e:
            logger.error("Failed to write to PostgreSQL: %s", str(e))

    def run_training_pipeline(self) -> dict:
        logger.info("Fetching data...")
        df = self._fetch_data()
        if df.empty:
            raise RuntimeError("No data available for training.")

        logger.info("Shaping & encoding features...")
        df = self._coerce_schema(df)
        if df.empty or df["is_fraud"].sum() == 0:
            logger.warning("Dataset has no positive fraud labels; training will be trivial.")
        else:
            # Write the raw (preprocessed) data each run to PostgreSQL for persistence
            try:
                self._write_to_postgres(df)
            except Exception as ex:
                logger.warning("Writing to PostgreSQL failed: %s", str(ex))

        X_train, X_test, y_train, y_test = self._split(df)

        with mlflow.start_run(run_name="xgb_fraud_training"):
            logger.info("Training XGBoost...")
            model = self._train(X_train, y_train)

            logger.info("Evaluating...")
            metrics = self._eval(model, X_test, y_test)
            logger.info("Metrics: %s", json.dumps(metrics, indent=2))

            # Log params & metrics
            for k, v in self.config["model"].items():
                mlflow.log_param(k, v)
            for k, v in metrics.items():
                mlflow.log_metric(k, v)

            # Log model
            mlflow.xgboost.log_model(model, artifact_path="model")

        return metrics
