from fraud_detection_training import FraudDetectionTraining
import os

if __name__ == "__main__":
    # Locate config.yaml in project root
    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    config_path = os.path.join(project_root, "config.yaml")

    if not os.path.exists(config_path):
        raise FileNotFoundError(f"config.yaml not found at {config_path}")

    trainer = FraudDetectionTraining(config_path=config_path)
    metrics = trainer.run_training_pipeline()

    print("\n✅ Training completed. Metrics:")
    print(metrics)
