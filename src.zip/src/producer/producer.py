import os
import time
import random
import json
import signal
import logging
import yaml
from faker import Faker
from datetime import datetime, timezone
from jsonschema import validate, ValidationError, FormatChecker
from confluent_kafka import Producer
from dotenv import load_dotenv

# ------------------- Logging -------------------
logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(module)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# ------------------- Load environment variables -------------------
load_dotenv(dotenv_path=".env")

# ------------------- Faker instance -------------------
fake = Faker()

# ------------------- JSON Schema -------------------
TRANSACTION_SCHEMA = {
    "type": "object",
    "properties": {
        "transaction_id": {"type": "string"},
        "user_id": {"type": "number", "minimum": 1000, "maximum": 9999},
        "amount": {"type": "number", "minimum": 0.01, "maximum": 10000},
        "currency": {"type": "string", "pattern": "^[A-Z]{3}$"},
        "merchant": {"type": "string"},
        "timestamp": {"type": "string", "format": "date-time"},
        "location": {"type": "string", "pattern": "^[A-Z]{2}$"},
        "is_fraud": {"type": "integer", "minimum": 0, "maximum": 1}
    },
    "required": ["transaction_id", "user_id", "amount", "currency", "timestamp"]
}

# ------------------- Transaction Producer -------------------
class TransactionProducer:
    def __init__(self):
        # Locate config.yaml in project root
        project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        config_path = os.path.join(project_root, "config.yaml")

        if not os.path.exists(config_path):
            raise FileNotFoundError(f"config.yaml not found at {config_path}")

        # Load YAML config
        with open(config_path, "r") as f:
            self.config = yaml.safe_load(f)

        # Kafka config
        kafka_conf = self.config['kafka']
        self.bootstrap_servers = kafka_conf.get('bootstrap_servers', '127.0.0.1:29092')
        self.topic = kafka_conf.get('topic', 'transactions')
        self.running = False

        self.producer_config = {
            'bootstrap.servers': self.bootstrap_servers,
            'client.id': 'transaction-producer',
            'compression.type': 'gzip',
            'linger.ms': 5,
            'batch.size': 16384,
        }

        try:
            self.producer = Producer(self.producer_config)
            logger.info(f'Kafka producer connected to {self.bootstrap_servers}')
        except Exception as e:
            logger.error(f'Kafka producer init failed: {e}')
            raise

        # Fraud simulation setup
        self.compromised_users = set(random.sample(range(1000, 9999), 50))
        self.high_risk_merchants = ['QuickCash', 'GlobalDigital', 'FastMoneyX']

        # Graceful shutdown
        signal.signal(signal.SIGINT, self.shutdown)
        signal.signal(signal.SIGTERM, self.shutdown)

    # ------------------- Kafka delivery callback -------------------
    def delivery_report(self, err, msg):
        if err:
            logger.error(f'Delivery failed: {err}')
        else:
            logger.info(f'Message sent to {msg.topic()} [{msg.partition()}]')

    # ------------------- Validate transaction -------------------
    def validate_transaction(self, transaction):
        try:
            validate(instance=transaction, schema=TRANSACTION_SCHEMA, format_checker=FormatChecker())
            return True
        except ValidationError as e:
            logger.error(f'Invalid transaction: {e.message}')
            return False

    # ------------------- Generate transaction -------------------
    def generate_transaction(self):
        txn = {
            'transaction_id': fake.uuid4(),
            'user_id': random.randint(1000, 9999),
            'amount': round(fake.pyfloat(min_value=0.01, max_value=10000, right_digits=2), 2),
            'currency': 'USD',
            'merchant': fake.company(),
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'location': fake.country_code(),
            'is_fraud': 0
        }

        # Simulate fraud
        if txn['user_id'] in self.compromised_users and txn['amount'] > 500:
            if random.random() < 0.3:
                txn['is_fraud'] = 1
                txn['amount'] = round(random.uniform(500, 5000), 2)
                txn['merchant'] = random.choice(self.high_risk_merchants)

        return txn if self.validate_transaction(txn) else None

    # ------------------- Send transaction -------------------
    def send_transaction(self):
        txn = self.generate_transaction()
        if not txn:
            return False
        try:
            self.producer.produce(
                self.topic,
                key=txn['transaction_id'],
                value=json.dumps(txn),
                callback=self.delivery_report
            )
            self.producer.poll(0)
            return True
        except Exception as e:
            logger.error(f'Error producing: {e}')
            return False

    # ------------------- Graceful shutdown -------------------
    def shutdown(self, signum=None, frame=None):
        if self.running:
            logger.info('Stopping producer...')
            self.running = False
            if self.producer:
                self.producer.flush(30)
            logger.info('Producer stopped.')

    # ------------------- Continuous production -------------------
    def run_continuous_production(self, interval=1.0):
        self.running = True
        logger.info(f'Starting production to topic: {self.topic}')
        try:
            while self.running:
                self.send_transaction()
                time.sleep(interval)
        finally:
            self.shutdown()


# ------------------- Main -------------------
if __name__ == "__main__":
    producer = TransactionProducer()
    producer.run_continuous_production()
