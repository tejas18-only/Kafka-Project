from kafka import KafkaConsumer
import json
import pandas as pd
import os

KAFKA_BROKER = "localhost:29092"
TOPIC = "transactions"
CSV_FILE = "data/transactions.csv"

# Create data folder if not exists
os.makedirs("data", exist_ok=True)

consumer = KafkaConsumer(
    TOPIC,
    bootstrap_servers=[KAFKA_BROKER],
    value_deserializer=lambda m: json.loads(m.decode('utf-8')),
    auto_offset_reset="earliest",
    enable_auto_commit=True,
    group_id="fraud_detection_group"
)

print("Consumer started... Listening for messages...")

data_buffer = []
for message in consumer:
    transaction = message.value
    print(f"Received: {transaction}")
    data_buffer.append(transaction)

    # Save every 50 messages
    if len(data_buffer) >= 50:
        df = pd.DataFrame(data_buffer)
        if os.path.exists(CSV_FILE):
            df.to_csv(CSV_FILE, mode='a', header=False, index=False)
        else:
            df.to_csv(CSV_FILE, index=False)
        data_buffer = []
