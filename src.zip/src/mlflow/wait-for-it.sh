#!/usr/bin/env bash

TIMEOUT=15
QUIET=0

usage() {
  echo "Usage: $0 host:port [-t timeout] [-q] -- command args"
  exit 1
}


wait_for() {
  local host=$1
  local port=$2
  local timeout=$3

  for ((i=0; i<timeout; i++)); do
    if nc -z "$host" "$port"; then
      return 0
    fi
    sleep 1
  done
  return 1
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    -t|--timeout)
      TIMEOUT="$2"
      shift 2
      ;;
    -q|--quiet)
      QUIET=1
      shift
      ;;
    --)
      shift
      break
      ;;
    *)
      HOST_PORT="$1"
      shift
      ;;
  esac
done

if [[ -z "$HOST_PORT" || $# -eq 0 ]]; then
  usage
fi

HOST=$(echo "$HOST_PORT" | cut -d: -f1)
PORT=$(echo "$HOST_PORT" | cut -d: -f2)

if [[ -z "$HOST" || -z "$PORT" ]]; then
  usage
fi

if ! wait_for "$HOST" "$PORT" "$TIMEOUT"; then
  if [[ $QUIET -ne 1 ]]; then
    echo "Timeout waiting for $HOST:$PORT"
  fi
  exit 1
fi

exec "$@"
